package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class StripesMapper extends Mapper<LongWritable, Text, Text, MapWritable>{

	private MapWritable occMap = new MapWritable();
	private Text word = new Text();
	//private int oneValue = 1;
	@Override 
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		//int neighbours = context.getConfiguration().getInt("neighbours", 2);
		
		String[] row = value.toString().split("\n");
		//int counter =0;
		String[] myHashTag = {"#ArvindKejriwal", 
				"#AAP" ,
				"#Kejriwal", 
				"#IndianElections" ,
				"#aamaadmiparty" ,
				"#askKejriwal" ,
				"#AK49", 
				"#loksabhaElections",
				"#indianelections2014", 
				"#IndianDemocracy",
				"#Elections2014" ,
				"#IndiaVotes" ,
				"#DanceofDemocracy" ,
				"#VoteForBetterIndia" ,
				"#loksabha2014", 
				"#loksabhapolls",
				"#indiapolls2014",
				"#NaMo",
				"#WhyPMModi",
				"#BJP",
				"#Namo4PM",
				"#NarendraModi",
				"#Election2014",
				"#Modi", 
				"#loksabhaElections", 
				"#indianelections2014",
				"#IndianDemocracy",
				"#SatyamevJayate",
				"#IndiaVotes",
				"#VoteForBetterIndia",
				"#loksabha2014",
				"#loksabhapolls",
				"#SSindiapolls2014"} ;
		
		for ( int  i=0 ;i< row.length; i++)
		{
			String[] itr = row[i].split(",");
			String[] terms  = itr[0].split("\\s+");
			for(int w=0; w<terms.length;w++)
			{
				
				for(int h=0; h<myHashTag.length;h++)
				{
					//counter =0;
					if (terms[w].equalsIgnoreCase(myHashTag[h]) )
					{
						word.set(terms[w]);
						occMap.clear();
						for ( int j = 0; j< terms.length; j++)
						{
							//if()
							if (j==w) continue; 
							Text neighbour = new Text(terms[j]);
							if (occMap.containsKey(neighbour))
							{
								IntWritable count  =  (IntWritable)occMap.get(neighbour);
								count.set(count.get() + 1);
								//counter++;
								
							}
							else 
							{
								occMap.put(neighbour, new IntWritable(1));
								//counter++;
							}
						}
						context.write(word, occMap);
					}
					//context.write(word, new IntWritable(counter));
				}
			}
		}	
	}
}