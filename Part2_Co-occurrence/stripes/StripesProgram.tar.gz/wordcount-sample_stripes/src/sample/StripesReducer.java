package sample;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class StripesReducer
 extends Reducer<Text, MapWritable, Text, Text> {
	
	
	@Override
	public void reduce(Text key , Iterable<MapWritable> values, Context context) throws IOException, InterruptedException 
	{
		double totalValueTag =0 ;
		int currentValue =0;
		int counter =0 ;
		int counterAccess =0;
		//int[] numArr = new int[values.]
		//ArrayList<String> numArr = new ArrayList<String>();
		MapWritable result = new MapWritable();
		result.clear();
		for (MapWritable val : values) 
		{
			Set<Writable> keys  = val.keySet();
			for (Writable key1 : keys) 
			{
				IntWritable intialCount = (IntWritable)val.get(key1);
				if (result.containsKey(key1))
				{
					IntWritable count = (IntWritable)result.get(key1);
					count.set(count.get() + intialCount.get());	
					totalValueTag = totalValueTag + count.get() + intialCount.get();
				}
				else 
				{
					result.put(key1, intialCount);
					totalValueTag = totalValueTag + intialCount.get();
					
				}
				//currentValue++;
			}
			//counter++;
			//numArr.add(String.valueOf(currentValue));
			//currentValue =0;
			
			//totalValueTag = totalValueTag +  currentValue;
			//currentValue =0;
		}
		//String finalValue = new String();
		Text finalValue = new Text();
		String fString = new String();
		//result
		Set<Writable> qwerty = result.keySet();
	   // Collection<Writable> qwerty2 = result.values();
	    
	    for (Writable a : qwerty)
	    {
	    	if (a != null)
	    	{
	    		if (fString != null)
	    		{
		    		if (fString.length() > 0)
		    		{
		    			
		    			fString = fString + " , " +  a.toString() + "-"+ result.get(a).toString() 
		    					+ "| Frequency: " +
		    					String.valueOf(Double.parseDouble(result.get(a).toString())/totalValueTag);
		    	//String.valueOf((Integer.parseInt(numArr.get(counterAccess))/totalValueTag));
		    		}
		    		else 
		    		{
		    			fString = a.toString() + "-"+ result.get(a).toString() 
		    					+ "| Frequency: " + 
		    					String.valueOf(Double.parseDouble(result.get(a).toString())/totalValueTag);
		    		}
		    		counterAccess++;
	    		}
	    	}
	    }
	    finalValue.set(fString + "\n");
		/*for (Writable aa : qwerty)
		{
			if (aa != null)
			{
				finalValue = 
			}
		}*/
		
		
		context.write(key, finalValue);
	}
}
