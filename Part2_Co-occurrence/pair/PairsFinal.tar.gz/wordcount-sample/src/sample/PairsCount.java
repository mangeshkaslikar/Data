package sample;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PairsCount {

	private static final transient Logger LOG = LoggerFactory.getLogger(PairsCount.class);

	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();		

		LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
		LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
		/* Set the Input/Output Paths on HDFS */
		String inputPath = "/input";
		String outputPath = "/output";

		/* FileOutputFormat wants to create the output directory itself.
		 * If it exists, delete it:
		 */
		deleteFolder(conf,outputPath);
		
		Job job = Job.getInstance(conf);

		job.setJarByClass(PairsCount.class);
		//job.getConfiguration().setInt("window", );
		job.setMapperClass(WordPairMapper.class);
		//job.setCombinerClass(WordPairReducer.class);
		job.setPartitionerClass(DataPartitionerPairs.class);
		job.setReducerClass(WordPairReducer.class);
		//job.setPartitionerClass(DataPartitioner.class);
		job.setNumReduceTasks(4);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
	
	/*public class DataPartitioner extends Partitioner<Text,IntWritable> {

	    @Override
	    public int getPartition(Text wordPair, IntWritable intWritable, int numPartitions) {
	        String[] key = wordPair.toString().split(",");
	    	int a =key[0].hashCode() % numPartitions ;
	        //return wordPair.getWord().hashCode() % numPartitions;
	    	return a ;
	    }
	}*/
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}