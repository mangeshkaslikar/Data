package sample;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WordPairReducer
 extends Reducer<Text, IntWritable, Text, Text> {
	private Text result = new Text();
	private Text result2 = new Text();
	private double totalValue =0, totalValue2 =0,totalValue3 =0, totalValue4 =0;
	int checkFlag1 =0 ,checkFlag2 =0,checkFlag3 =0,checkFlag4 =0;
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		double sum = 0;
		/*	 "#ArvindKejriwal", 
		"#AAP" ,
		"#Kejriwal", 
		"#IndianElections" ,
		"#aamaadmiparty" ,
		"#askKejriwal" ,"#AK49", "#loksabhaElections","#indianelections2014", "#IndianDemocracy",
		"#Elections2014" ,
		"#IndiaVotes" ,
		"#DanceofDemocracy" ,"#VoteForBetterIndia" ,"#loksabha2014", "#loksabhapolls","#indiapolls2014",
		"#NaMo","#WhyPMModi","#BJP","#Namo4PM","#NarendraModi","#Election2014","#Modi", "#loksabhaElections", 
		"#indianelections2014","#IndianDemocracy","#SatyamevJayate",
		"#IndiaVotes","#VoteForBetterIndia","#loksabha2014",
		"#loksabhapolls",
		"#SSindiapolls2014"*/
		
		
		if (key.toString().equalsIgnoreCase("#ArvindKejriwal")|| key.toString().equalsIgnoreCase("#AAP")
|| key.toString().equalsIgnoreCase("#Kejriwal") || key.toString().equalsIgnoreCase("#IndianElections")
			|| key.toString().equalsIgnoreCase("#aamaadmiparty") || key.toString().equalsIgnoreCase("#askKejriwal")
			|| key.toString().equalsIgnoreCase("#AK49") || key.toString().equalsIgnoreCase("#loksabhaElections")
			 )
		{
			checkFlag1 = 1;
			checkFlag2 = 0;
			checkFlag3 = 0;
			checkFlag4 = 0;
			for (IntWritable val : values) 
			{
				totalValue += val.get();
			}
			result2.set(String.valueOf(totalValue));
			context.write(key, result2);
			result2.clear();
		}
		if (key.toString().equalsIgnoreCase("#indianelections2014")|| key.toString().equalsIgnoreCase("#IndianDemocracy")
|| key.toString().equalsIgnoreCase("#Elections2014") || key.toString().equalsIgnoreCase("#IndiaVotes")
			|| key.toString().equalsIgnoreCase("#DanceofDemocracy") || key.toString().equalsIgnoreCase("#VoteForBetterIndia")
			|| key.toString().equalsIgnoreCase("#loksabha2014") || key.toString().equalsIgnoreCase("#loksabhapolls")
			 )
		{

			checkFlag1 = 0;
			checkFlag2 = 1;
			checkFlag3 = 0;
			checkFlag4 = 0;
			for (IntWritable val : values) 
			{
				totalValue2 += val.get();
			}
			result2.set(String.valueOf(totalValue2));
			context.write(key, result2);
			result2.clear();
		}
		/*
		 "#indiapolls2014",
		"#NaMo","#WhyPMModi","#BJP","#Namo4PM","#NarendraModi","#Election2014","#Modi", "#loksabhaElections", 
		"#indianelections2014","#IndianDemocracy","#SatyamevJayate",
		"#IndiaVotes","#VoteForBetterIndia","#loksabha2014",
		"#loksabhapolls",
		"#SSindiapolls2014"*/
		 
		if (key.toString().equalsIgnoreCase("#indiapolls2014")|| key.toString().equalsIgnoreCase("#NaMo")
|| key.toString().equalsIgnoreCase("#WhyPMModi") || key.toString().equalsIgnoreCase("#BJP")
			|| key.toString().equalsIgnoreCase("#Namo4PM") || key.toString().equalsIgnoreCase("#NarendraModi")
			|| key.toString().equalsIgnoreCase("#Election2014") || key.toString().equalsIgnoreCase("#Modi")
			 )
		{

			checkFlag1 = 0;
			checkFlag2 = 0;
			checkFlag3 = 1;
			checkFlag4 = 0;
			for (IntWritable val : values) 
			{
				totalValue3 += val.get();
			}
			result2.set(String.valueOf(totalValue3));
			context.write(key, result2);
			result2.clear();
		}
		if (key.toString().equalsIgnoreCase("#loksabhaElections")|| key.toString().equalsIgnoreCase("#indianelections2014")
|| key.toString().equalsIgnoreCase("#IndianDemocracy") || key.toString().equalsIgnoreCase("#SatyamevJayate")
			|| key.toString().equalsIgnoreCase("#SSindiapolls2014") || key.toString().equalsIgnoreCase("#loksabhapolls")
			
			 )
		{

			checkFlag1 = 0;
			checkFlag2 = 0;
			checkFlag3 = 0;
			checkFlag4 = 1;
			for (IntWritable val : values) 
			{
				totalValue4 += val.get();
			}
			result2.set(String.valueOf(totalValue4));
			context.write(key, result2);
			result2.clear();
		}
		else 
		{
			for (IntWritable val : values) 
			{
				sum += val.get();
			}
			double frequency =0;
			if (checkFlag1 > 0)
			{
				if(totalValue > 0)
					frequency  = sum/totalValue;
				
			}
			if (checkFlag2 > 0)
			{
				if (totalValue2 > 0)
					frequency  = sum/totalValue2;
			}
			if (checkFlag3 > 0)
			{
				if (totalValue3 > 0)
					frequency  = sum/totalValue3;
			}
			if (checkFlag4 > 0)
			{
				if (totalValue4 > 0)
					frequency  = sum/totalValue4;
			}
				result.set("|" + "Count: " + String.valueOf(sum) + " - " + "Frequency: " + String.valueOf(frequency))  ;
				context.write(key, result);
				result.clear();
			
		}
	}
}