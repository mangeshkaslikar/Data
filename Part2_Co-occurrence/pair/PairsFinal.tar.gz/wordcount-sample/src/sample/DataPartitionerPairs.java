package sample;

//import java.io.IOException;
//import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class DataPartitionerPairs extends Partitioner<Text,IntWritable> {
	
	//@Override
	public int getPartition(Text key, IntWritable value,int numReduceTasks)
	{
		if (numReduceTasks == 0)
			return 0;
		//if (key.equals("#AAP") || key.equals("#ArvindKejriwal")|| key.equals("#Kejriwal")
		//|| key.equals("#IndianElections") || key.equals("#aamaadmiparty") || 
	//	key.equals("#askKejriwal"))
		// Decide Number of Reducers based on Number of Hastags . 
	/*	 "#ArvindKejriwal", 
"#AAP" ,
"#Kejriwal", 
"#IndianElections" ,
"#aamaadmiparty" ,
"#askKejriwal" ,"#AK49", "#loksabhaElections","#indianelections2014", "#IndianDemocracy",
"#Elections2014" ,
"#IndiaVotes" ,
"#DanceofDemocracy" ,"#VoteForBetterIndia" ,"#loksabha2014", "#loksabhapolls","#indiapolls2014",
"#NaMo","#WhyPMModi","#BJP","#Namo4PM","#NarendraModi","#Election2014","#Modi", "#loksabhaElections", 
"#indianelections2014","#IndianDemocracy","#SatyamevJayate",
"#IndiaVotes","#VoteForBetterIndia","#loksabha2014",
"#loksabhapolls",
"#SSindiapolls2014"*/ 
		String[] splitPair  = key.toString().split(",");
		if(splitPair[0].equalsIgnoreCase("#ArvindKejriwal") || splitPair[0].equalsIgnoreCase("#AAP")
				|| splitPair[0].equalsIgnoreCase("#Kejriwal") || splitPair[0].equalsIgnoreCase("#IndianElections")
				|| splitPair[0].equalsIgnoreCase("#aamaadmiparty") || splitPair[0].equalsIgnoreCase("#askKejriwal")
				|| splitPair[0].equalsIgnoreCase("#AK49") || splitPair[0].equalsIgnoreCase("#loksabhaElections"))
		{
			return 0;
			
		}
		if(splitPair[0].equalsIgnoreCase("#indianelections2014") || splitPair[0].equalsIgnoreCase("#IndianDemocracy")
				|| splitPair[0].equalsIgnoreCase("#Elections2014") || splitPair[0].equalsIgnoreCase("#IndiaVotes")
				|| splitPair[0].equalsIgnoreCase("#DanceofDemocracy") || splitPair[0].equalsIgnoreCase("#VoteForBetterIndia")
				|| splitPair[0].equalsIgnoreCase("#loksabha2014") || splitPair[0].equalsIgnoreCase("#loksabhapolls"))
		{
			return 1 % numReduceTasks;
		}
		if(splitPair[0].equalsIgnoreCase("#indiapolls2014") || splitPair[0].equalsIgnoreCase("#NaMo")
				|| splitPair[0].equalsIgnoreCase("#WhyPMModi") || splitPair[0].equalsIgnoreCase("#BJP")
				|| splitPair[0].equalsIgnoreCase("#Namo4PM") || splitPair[0].equalsIgnoreCase("#NarendraModi")
				|| splitPair[0].equalsIgnoreCase("#Election2014") || splitPair[0].equalsIgnoreCase("#Modi"))
		{
			return 2 % numReduceTasks;
		}
		else 
		{
			return 3 % numReduceTasks;
		}
		//return 0;
	}	
}
	

