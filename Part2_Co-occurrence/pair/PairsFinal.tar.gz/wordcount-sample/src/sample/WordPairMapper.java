package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
 

public class WordPairMapper extends Mapper<Object, Text, Text, IntWritable>{

	private final static IntWritable one = new IntWritable(1);
	//private TextPair word = new TextPair();
	private Text word = new Text();
	private Text wordMain = new Text();
	//word
	
	public int window =1;
	//private int oneValue = 1;
	
	public void setup(Context context)
	{
		window  = context.getConfiguration().getInt("window", 2);
	}

	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		String[] row = value.toString().split("\n");
		
		
		for (int i=0 ; i<row.length ; i++)
		{
			String[] itration = row[i].split(",");
			String[] terms  = itration[0].split("\\s+");
			
			
			for ( int w=0 ;w<terms.length-1; w++)
			{
				/*
				 "#ArvindKejriwal", 
"#AAP" ,
"#Kejriwal", 
"#IndianElections" ,
"#aamaadmiparty" ,
"#askKejriwal" ,"#AK49", "#loksabhaElections","#indianelections2014", "#IndianDemocracy",
"#Elections2014" ,
"#IndiaVotes" ,
"#DanceofDemocracy" ,"#VoteForBetterIndia" ,"#loksabha2014", "#loksabhapolls","#indiapolls2014",
"#NaMo","#WhyPMModi","#BJP","#Namo4PM","#NarendraModi","#Election2014","#Modi", "#loksabhaElections", 
"#indianelections2014","#IndianDemocracy","#SatyamevJayate",
"#IndiaVotes","#VoteForBetterIndia","#loksabha2014",
"#loksabhapolls",
"#SSindiapolls2014"
				 */
				String term  = terms[w];
				if (term.equalsIgnoreCase("#ArvindKejriwal") || (term.equalsIgnoreCase("#AAP"))
					||(term.equalsIgnoreCase("#Kejriwal"))||(term.equalsIgnoreCase("#IndianElections"))
					||(term.equalsIgnoreCase("#aamaadmiparty"))||(term.equalsIgnoreCase("#askKejriwal"))
					||(term.equalsIgnoreCase("#AK49"))||(term.equalsIgnoreCase("#loksabhaElections"))
					||(term.equalsIgnoreCase("#indianelections2014"))||(term.equalsIgnoreCase("#IndianDemocracy"))
					||(term.equalsIgnoreCase("#Elections2014"))||(term.equalsIgnoreCase("#IndiaVotes"))
					||(term.equalsIgnoreCase("#DanceofDemocracy"))||(term.equalsIgnoreCase("#VoteForBetterIndia"))
					||(term.equalsIgnoreCase("#loksabha2014"))||(term.equalsIgnoreCase("#loksabhapolls"))
					||(term.equalsIgnoreCase("#indiapolls2014"))||(term.equalsIgnoreCase("#NaMo"))
					||(term.equalsIgnoreCase("#WhyPMModi"))||(term.equalsIgnoreCase("#BJP"))
					||(term.equalsIgnoreCase("#Namo4PM"))||(term.equalsIgnoreCase("#NarendraModi"))
					||(term.equalsIgnoreCase("#Election2014"))||(term.equalsIgnoreCase("#Modi"))
					||(term.equalsIgnoreCase("#loksabhaElections"))||(term.equalsIgnoreCase("#indianelections2014"))
					||(term.equalsIgnoreCase("#IndianDemocracy"))||(term.equalsIgnoreCase("#SatyamevJayate"))
					||(term.equalsIgnoreCase("#IndiaVotes"))||(term.equalsIgnoreCase("#SSindiapolls2014"))
					||(term.equalsIgnoreCase("#loksabhapolls")))
					//||(term.equalsIgnoreCase("#AAP"))||(term.equalsIgnoreCase("#AAP")))
					// Add All possible hashTags here 
				{
					
					
					if (term.length() >0 )
					{
						for (int e=w+1 ; e <terms.length ; e++)
						{
							//word.set(term, terms[e]);
							word.set(term + "," + terms[e]);
							context.write(word, one);	
							wordMain.set(term);
							context.write(wordMain, one);
							word.clear();
						}
					}
				}
			}
			
		}
	}
}