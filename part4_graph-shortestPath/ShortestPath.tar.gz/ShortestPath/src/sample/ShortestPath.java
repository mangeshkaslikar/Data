package sample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;

//import javax.swing.text.html.HTMLDocument.Iterator;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShortestPath 
{
	private static final transient Logger LOG = LoggerFactory.getLogger(ShortestPath.class);

	public static void main(String[] args) throws Exception 
	{
		
		HashMap<Integer, Integer> newHashMap = new HashMap<Integer,Integer>();
		HashMap<Integer, Integer> oldHashMap = new HashMap<Integer,Integer>();
		boolean isComplete = true; 
		int iteration =0;
		String inputPath = "";
		String outputPath = "/output";
		Configuration conf = new Configuration();
		boolean successFlag = false;
		int successBit = 0;
		deleteFolder(conf, outputPath); // previous program Delete Output Folder 
		
		while (isComplete)
		{
			iteration++;
				
			LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
			LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
			
			//if(iteration == 1)
			//{
				
			//}
			
			// Delete previous Files 
			
			
			Job job = Job.getInstance(conf);
			
			job.setJarByClass(ShortestPath.class);
			job.setMapperClass(ShortestPathMapper.class);
			//job.setCombinerClass(StripesReducer.class);
			job.setReducerClass(ShortestPathReducer.class);
			//job.setPartitionerClass(DataPartitioner.class);
			job.setNumReduceTasks(1);
			
			job.setMapOutputKeyClass(LongWritable.class);
			job.setMapOutputValueClass(Text.class);
			//job.setInputFormatClass(cls););
			
			job.setOutputKeyClass(LongWritable.class);
			job.setOutputValueClass(Text.class);
			
			inputPath = "/input";
			FileInputFormat.addInputPath(job, new Path(inputPath));
			outputPath = "/output";
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			
			successFlag = job.waitForCompletion(true);
			
			if (successFlag == true)
				successBit = 0;
			else 
				successBit = 1;
			
			
			
			
			// New Input to the Mapper
			
			//deleteFolder(conf, inputPath);
			FileSystem fOpen = FileSystem.get(conf);
			if (iteration == 1)
			{
				Path filePath = new Path(inputPath + "/input-graph-small");
				if (fOpen.exists(filePath))
				{
					fOpen.delete(filePath,true);
				}
			}
			else
			{
				Path filePath = new Path(inputPath + "/part-r-00000");
				if (fOpen.exists(filePath))
				{
					fOpen.delete(filePath,true);
				}
				
			}
			Path outputPathReduceFile = new Path(outputPath +"/part-r-00000");
			Path localFilepath = new Path("/home/hduser/");
			
			Path clearInputFolder  = new Path("/input");
			
				//fOpen.delete(filePath,true);
				//fOpen.copyToLocalFile(outputPath + "/part-r-00000", "/home/hduser/");
			
			
			fOpen.copyToLocalFile(outputPathReduceFile,localFilepath);
			Path InputLocalFilePath = new Path("/home/hduser/part-r-00000");
			//
			fOpen.copyFromLocalFile(InputLocalFilePath, clearInputFolder);
			Path inputPathPlusRedFile = new Path("/input/part-r-00000");
			deleteFolder(conf, outputPath);
			
			
			
			//inputPath = outputPath + "/part-r-00000";
			
			// Copy Contents into New and Old Hashmap 
			isComplete = false;
			
			BufferedReader reader = new 
					BufferedReader(new InputStreamReader(fOpen.open(inputPathPlusRedFile)));
			
			String line = reader.readLine();
			if (newHashMap.isEmpty() == false) // clearing old contents.
		 		newHashMap.clear();
			 while (line != null)
			 {
	                //each line looks like 0 1 2:3:
	                //we need to verify node -> distance doesn't change
				 	
	                String[] sp = line.split("\t");
	                int node = Integer.parseInt(sp[0]);
	                int distance = Integer.parseInt(sp[1].split(" ")[0]);
	                newHashMap.put(node, distance);
	                line=reader.readLine();
	         }
			reader.close();
			
			 if (oldHashMap.isEmpty()) // should be running for second time atleast . 
			 {
				 isComplete = true;
			 }
			 else 
			 {
				// Iterator itr = newHashMap.keySet().iterator();
				 Iterator<Integer> itr = newHashMap.keySet().iterator();
				 
				 while (itr.hasNext())
				 {
					 int key = itr.next();
					 int value = newHashMap.get(key);
					 if (oldHashMap.get(key) != value)
					 {
						 isComplete = true;	 
					 }
				 } 
			 }
			 if (isComplete == true)
			 {
				 if (oldHashMap.isEmpty() == false)
					 oldHashMap.clear(); // clear out old contents . 
				 oldHashMap.putAll(newHashMap);
			 }
			
		}
		System.exit(successBit);
			
	}
		
		
		
		
		
		
		
		/* Set the Input/Output Paths on HDFS */
		

		/* FileOutputFormat wants to create the output directory itself.
		 * If it exists, delete it:
		 */
	//	deleteFolder(conf,outputPath);
		
		

		
		
		
//	}
	
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
			
		//	fs.
			
			//fs.cop
			
			//fs.copyFromLocalFile(src, dst);
		
		}
	}
}