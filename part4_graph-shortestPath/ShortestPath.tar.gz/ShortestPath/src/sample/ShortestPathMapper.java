package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ShortestPathMapper extends Mapper<LongWritable, Text, LongWritable, Text>{

	private MapWritable occMap = new MapWritable();
	private Text word = new Text();
	//private int oneValue = 1;
	@Override 
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		String line = value.toString();
		String[] splitValues = line.split("\t");
		//int  distancetoAdd = Integer.parseInt(splitValues[1]) + 1;
		String distAdd = Integer.toString(Integer.parseInt(splitValues[1].split(" ")[0]) + 1);
		
		String[] neighbours = splitValues[1].split(" ")[1].split(":");
		// Set Neighbours 
		for (int q =0 ;q<neighbours.length;q++)
		{
			word.set(distAdd);
			context.write(new LongWritable(Integer.parseInt(neighbours[q])), word);
			word.clear();
		}
		
		word.set(splitValues[1].split(" ")[0]);
		context.write(new LongWritable(Integer.parseInt(splitValues[0])), word);
		word.clear();
		
		word.set("NodeInfo " + splitValues[1].split(" ")[1]);
		context.write(new LongWritable(Integer.parseInt(splitValues[0])), word);
		word.clear();
		
		

		
	}
}