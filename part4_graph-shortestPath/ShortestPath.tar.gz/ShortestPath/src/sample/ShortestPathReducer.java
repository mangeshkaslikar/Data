package sample;

import java.io.IOException;
import java.util.Collection;
import java.util.Set;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class ShortestPathReducer
 extends Reducer<LongWritable, Text, LongWritable, Text> {
	//private MapWritable result = new MapWritable();
	Text word = new Text();
	@Override
	public void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException 
	{
		String nodes ="Unaffected";
		//Text word  = new 
		int lowest = 11000;
		for (Text txt : values)
		{
			String[] splitValue = txt.toString().split(" ");
			
			if(splitValue[0].equalsIgnoreCase("NodeInfo"))
			{
				nodes = null;
				nodes = splitValue[1];
			}
			else
			{
				int dist = Integer.parseInt(splitValue[0]);
				lowest  = Math.min(dist, lowest);
			}
		}
		word.set(lowest+" "+nodes);
		context.write(key,word);
		word.clear();
	}
}
