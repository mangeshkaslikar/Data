package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.omg.PortableInterceptor.SUCCESSFUL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KMeansDriver {

	private static final transient Logger LOG = LoggerFactory.getLogger(KMeansDriver.class);
//	boolean success_Flag = false;
	
	@SuppressWarnings("null")
	public static void main(String[] args) throws Exception
	{
		Configuration conf = new Configuration();		
		
	    boolean success_Flag = true;
	    int successBit = 0;
	    
	    String inputPath = "/input";
		String outputPath = "/output";
		
	    deleteFolder(conf,outputPath);
	    
	    while (success_Flag)
	    {
			LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
			LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
			/* Set the Input/Output Paths on HDFS */
			
	
			/* FileOutputFormat wants to create the output directory itself.
			 * If it exists, delete it:
			 */
			//deleteFolder(conf,outputPath);
			
			Job job = Job.getInstance(conf);
	
			//deleteFolder(conf,outputPath);
			 
			job.setJarByClass(KMeansDriver.class);
			job.setMapperClass(KMeansMapper.class);
			//job.setCombinerClass(KMeansReducer.class);
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(IntWritable.class);
			job.setReducerClass(KMeansReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(IntWritable.class);
			FileInputFormat.addInputPath(job, new Path(inputPath));
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			
			success_Flag = job.waitForCompletion(true);
			
			if (success_Flag == true)
				successBit = 0;
			else 
				successBit = 1;
			
			FileSystem fOpen = FileSystem.get(conf);
			Path localDir = new Path("/home/hduser/");
			
			// Output File Read 
			Path outputPathReduceFile = new Path(outputPath +"/part-r-00000");
			BufferedReader reader = new 
					BufferedReader(new InputStreamReader(fOpen.open(outputPathReduceFile)));
		
			int[] totCent = new int[3];
			int iteration =0;
			String[] outputVariables = new String[3];
			
			String line = reader.readLine();
			while (line != null)
			{
				//iteration++;
				String[] sp = line.split(":");
				if (sp.length > 0)
				{
					outputVariables[iteration] = sp[0];	
		            totCent[iteration] = Integer.parseInt(sp[1].trim());
		            line=reader.readLine();
		            iteration++;
				}
			}
			reader.close();
			
			// Input File read 
			Path inputPathFile = new Path(inputPath + "/KmeansData");
			Path pureInputPath = new Path("/input/");
			BufferedReader reader1 = new 
					BufferedReader(new InputStreamReader(fOpen.open(inputPathFile)));
		
			String[] totInputCent = new String[3];
		
			String line1 = reader1.readLine();
			String[] spinput = line1.split(" ");
			totInputCent = spinput[1].split(":");
	        reader1.close();
			
	        // To count number of values  
	    	BufferedReader reader3 = new 
					BufferedReader(new InputStreamReader(fOpen.open(inputPathFile)));
		    
	    	String line3 = reader3.readLine(); 
	    	int numberOfEntries =0;
	    	while(line3 != null)
	    	{
	    		numberOfEntries++;
	    		line3 = reader3.readLine();
	    	}
	    	reader3.close();
	    	
	        
			// get Contents of Orginal file 
	        BufferedReader reader2= new 
					BufferedReader(new InputStreamReader(fOpen.open(inputPathFile)));
	        String line2 = reader2.readLine();
	        String[] orgList  = new String[numberOfEntries];
	        int counter =0 ;
	        while (line2 != null)
	        {
	        	//counter = counter + 1 ;
	        	if ( counter == 0)
	        	{
	        		orgList[counter] =  line2.split(" ")[0].trim();
	        	}
	        	else 
	        	{
	        		orgList[counter] = line2.toString().trim();
	        	}
	        	line2=reader2.readLine();
	        	counter = counter + 1;
	        }	
	        
	        reader2.close();
	        
			
			// Convergence Condition 
			if ((Math.abs(totCent[0]-Integer.parseInt(totInputCent[0])) < 2) && 
					(Math.abs(totCent[1]-Integer.parseInt(totInputCent[1])) < 2) && 
					(Math.abs(totCent[2]-Integer.parseInt(totInputCent[2])) < 2))
			{
				success_Flag = false;
				// copy File From input to Local
				//fOpen.copyToLocalFile(inputPathFile,localDir);
				//fOpen.
				// over-write contents onto new file 
				// Writer output = null;
				// File file = new File(localDir + "/KmeansData");
				// output = new BufferedWriter(new FileWriter(file));
				
				//Path filenamePath = new Path("/KmeansData.txt");
				// Delete Existing File 
				if (fOpen.exists(inputPathFile))
				{
					fOpen.delete(inputPathFile,true);
				
				}
				
				Path pureInputPathplusFile = new Path("/input/KmeansData");
				
	            FSDataOutputStream fin = fOpen.create(pureInputPathplusFile);
				
				 for ( int y =0 ;y < outputVariables.length; y++)
				 {
					 //output.write(totCent[y]+ " : " + outputVariables[y] + "\n");
					 
					 fin.writeUTF(totCent[y]+ " : " + outputVariables[y] + "\n");
					 
				 }
				 //output.write("hello");
				// output.close();
				 fin.flush();
				 fin.close();
				 
				// fOpen.copyToLocalFile(filenamePath, localDir);
			//	 Path LocalDirKmeans = new Path(localDir + "/KmeansData");
				 // copy back to input Dir 
				// fOpen.copyFromLocalFile(LocalDirKmeans, pureInputPath);
				
			}
			else
			{
				// copy File From input to Local
				
				//fOpen.copyToLocalFile(inputPathFile,localDir);
				// Delete file from input 
				if (fOpen.exists(inputPathFile))
				{
					fOpen.delete(inputPathFile,true);
				
				}
				// over-write contents onto new file 
				// Writer output = null;
				 //File file = new File(localDir + "/KmeansData");
				 //output = new BufferedWriter(new FileWriter(file));
				
			//	Path filenamePath = new Path("/KmeansData.txt");
				// Delete Existing File 
				//if (fOpen.exists(filenamePath))
				//{
					//fOpen.delete(filenamePath,true);
				
			//	}
				Path pureInputPathplusFile = new Path("/input/KmeansData");
				
	            FSDataOutputStream fin = fOpen.create(pureInputPathplusFile);
	           // fin.writeUTF(median+"");           

				 for ( int t =0 ;t <  orgList.length;t++)
				 {
					 if (t == 0)
					 {
						 fin.writeUTF(orgList[t] + " " +  totCent[0] + ":" + totCent[1] + ":" + totCent[2] + "\n");
					 }
					 else 
					 {
						 fin.writeUTF(orgList[t] + "\n");
					 }
				 }
				 //output.write("hello");
				 fin.flush();
		         fin.close();
				 //output.close();
				// Path LocalDirKmeans = new Path(localDir + "/KmeansData");
				 // copy back to input Dir 
		         //fOpen.copyToLocalFile(filenamePath, localDir);
				 //fOpen.copyFromLocalFile(localDir, pureInputPath);
				 
			}
			 deleteFolder(conf,outputPath);
				
	    }
		
		System.exit(successBit);
	}
	
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}