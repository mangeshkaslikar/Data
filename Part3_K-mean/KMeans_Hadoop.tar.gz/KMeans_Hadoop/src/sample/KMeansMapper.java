package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class KMeansMapper extends Mapper<Object, Text, Text, IntWritable>{

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
	private int iteration =0;
	private int centroid1=0, centroid2=0, centroid3=0;

	public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	{
		
		iteration++;
		if (iteration == 1)
		{
			String[] rowCentroid = value.toString().split(" ");
			String[] centroids = rowCentroid[1].split(":");
			centroid1 = Integer.parseInt(centroids[0]);
			centroid2 = Integer.parseInt(centroids[1]);
			centroid3 = Integer.parseInt(centroids[2]);
			
			int diff1, diff2, diff3;
			
			diff1 = Math.abs(Integer.parseInt(rowCentroid[0].trim())-centroid1);
			diff2 = Math.abs(Integer.parseInt(rowCentroid[0].trim())-centroid2);
			diff3 = Math.abs(Integer.parseInt(rowCentroid[0].trim())-centroid3);
			//if ()l
			int smallest = diff1;
			if (smallest > diff2) 
				smallest = diff2;
			if (smallest > diff3)
				smallest = diff3;
			
			if( smallest == diff1)
			{
				word.set("Cluster1 ");
				context.write(word,new IntWritable(Integer.parseInt(rowCentroid[0].trim())));
				word.clear();
			}
			if (smallest == diff2)
			{
				word.set("Cluster2 ");
				context.write(word,new IntWritable(Integer.parseInt(rowCentroid[0].trim())));
				word.clear();
			}
			if( smallest == diff3)
			{
				word.set("Cluster3 ");
				context.write(word,new IntWritable(Integer.parseInt(rowCentroid[0].trim())));
				word.clear();
			}
		}
		else 
		{
			String restNumString  = value.toString();
			int restNum = Integer.parseInt(restNumString.trim());
			
			int diff1, diff2, diff3;
			
			diff1 = Math.abs(restNum-centroid1);
			diff2 = Math.abs(restNum-centroid2);
			diff3 = Math.abs(restNum-centroid3);
			//if ()l
			int smallest = diff1;
			if (smallest > diff2) 
				smallest = diff2;
			if (smallest > diff3)
				smallest = diff3;
			
			if( smallest == diff1)
			{
				word.set("Cluster1 ");
				context.write(word,new IntWritable(restNum));
				word.clear();
			}
			if (smallest == diff2)
			{
				word.set("Cluster2 ");
				context.write(word,new IntWritable(restNum));
				word.clear();
			}
			if( smallest == diff3)
			{
				word.set("Cluster3 ");
				context.write(word,new IntWritable(restNum));
				word.clear();
			}
			
		}
		
		
		
		
		
		
		//int neighbours = context.getConfiguration().getInt("neighbours", 1);
		//String centroid1 ="",centroid2="",centroid3="";
		//String[] row = null;
		//iteration++;
		
		//context.write(value, new IntWritable(value.getLength()));
		//System.out.println(value.toString() + "Hello World ");
	//	if (value.getLength() == 0)
	//	{
			//row = value.toString().split("\n");
			//if (row.length > 0)
			//{
				// word.set("hello");
				 //context.write(word,new IntWritable(iteration));
				 //word.clear();
				/*String[] centroids = row[1].split(" ");
				if (centroids.length == 3)
				{
					 centroid1 = centroids[0].split(":")[1];
					 centroid2 = centroids[1].split(":")[1];
					 centroid3 = centroids[2].split(":")[1];
				}*/
			//}
		//}
		/*
		
		// Reading the file 
		/*for ( int  i=1 ;i< row.length; i++)
		{
			int itr = Integer.parseInt(row[i]);
			diff1 = Math.abs(itr-Integer.parseInt(centroid1));
			diff2 = Math.abs(itr-Integer.parseInt(centroid2));
			diff3 = Math.abs(itr-Integer.parseInt(centroid3));
			//if ()l
			int smallest = diff1;
			if (smallest > diff1) 
				smallest = diff2;
			if (smallest > diff3)
				smallest = diff3;
			
			if( smallest == diff1)
			{
				word.set("Cluster1 ");
				context.write(word,new IntWritable(itr));
				word.clear();
			}
			if (smallest == diff2)
			{
				word.set("Cluster2 ");
				context.write(word,new IntWritable(itr));
				word.clear();
			}
			if( smallest == diff3)
			{
				word.set("Cluster3 ");
				context.write(word,new IntWritable(itr));
				word.clear();
			}
			
			//cluster[i] = Integer.parseInt(itr[4].substring(0, 1));
			
		}*/ 
		// Declaring Cluster Centers .
	}
}