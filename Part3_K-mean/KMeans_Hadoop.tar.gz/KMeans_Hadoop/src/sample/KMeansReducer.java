package sample;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class KMeansReducer
extends Reducer<Text,IntWritable,Text,IntWritable> {
	//private MapWritable result = new MapWritable();
	Text word = new Text();
	
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException 
	{
		int sum =0;
		int counter =0;
		String valInSameClus = "";
		for (IntWritable itr : values)
		{
			sum  = sum +  itr.get();
			if(valInSameClus == "")
				valInSameClus = itr.toString();
			else 
				valInSameClus = valInSameClus + " " + itr.toString();
			counter++;
		}
		int mean = sum/counter;
		word.set(valInSameClus + " : ");
		//word.set(key.toString() + Integer.toString(counter));
		context.write(word, new IntWritable(mean));
	}
}

