package sample;

//import java.io.IOException;
//import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class DataPartitioner extends Partitioner<Text,IntWritable> {
	
	//@Override
	public int getPartition(Text key, IntWritable value,int numReduceTasks)
	{
		if (numReduceTasks == 0)
			return 0;
		//if (key.equals("#AAP") || key.equals("#ArvindKejriwal")|| key.equals("#Kejriwal")
		//|| key.equals("#IndianElections") || key.equals("#aamaadmiparty") || 
	//	key.equals("#askKejriwal"))
		if (key.toString().equalsIgnoreCase("#ArvindKejriwal") || (key.toString().equalsIgnoreCase("#AAP"))
				||(key.toString().equalsIgnoreCase("#Kejriwal"))||(key.toString().equalsIgnoreCase("#IndianElections"))
				||(key.toString().equalsIgnoreCase("#aamaadmiparty"))||(key.toString().equalsIgnoreCase("#askKejriwal"))
				||(key.toString().equalsIgnoreCase("#AK49"))||(key.toString().equalsIgnoreCase("#loksabhaElections"))
				||(key.toString().equalsIgnoreCase("#indianelections2014"))||(key.toString().equalsIgnoreCase("#IndianDemocracy"))
				||(key.toString().equalsIgnoreCase("#Elections2014"))||(key.toString().equalsIgnoreCase("#IndiaVotes"))
				||(key.toString().equalsIgnoreCase("#DanceofDemocracy"))||(key.toString().equalsIgnoreCase("#VoteForBetterIndia"))
				||(key.toString().equalsIgnoreCase("#loksabha2014"))||(key.toString().equalsIgnoreCase("#loksabhapolls"))
				||(key.toString().equalsIgnoreCase("#indiapolls2014"))||(key.toString().equalsIgnoreCase("#NaMo"))
				||(key.toString().equalsIgnoreCase("#WhyPMModi"))||(key.toString().equalsIgnoreCase("#BJP"))
				||(key.toString().equalsIgnoreCase("#Namo4PM"))||(key.toString().equalsIgnoreCase("#NarendraModi"))
				||(key.toString().equalsIgnoreCase("#Election2014"))||(key.toString().equalsIgnoreCase("#Modi"))
				||(key.toString().equalsIgnoreCase("#loksabhaElections"))||(key.toString().equalsIgnoreCase("#indianelections2014"))
				||(key.toString().equalsIgnoreCase("#IndianDemocracy"))||(key.toString().equalsIgnoreCase("#SatyamevJayate"))
				||(key.toString().equalsIgnoreCase("#IndiaVotes"))||(key.toString().equalsIgnoreCase("#SSindiapolls2014"))
				||(key.toString().equalsIgnoreCase("#loksabhapolls")))
		{
			return 0;
			
		}
		if (key.toString().startsWith("@"))
		{
			return 1 % numReduceTasks;
		}
		else 
		{
			return 2 % numReduceTasks;
		}
	}	
}
	


